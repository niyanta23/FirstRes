$(document).ready(function(){
    $("#requirement-form").submit(handleValidation);
    $("#categorydrop").focusin(hideMsg);
    $("#styledrop").focusin(hideMsg);
})

function handleValidation(e){
    
    let categorydrop = $('#categorydrop');
	let styledrop = $('#styledrop');

	if(categorydrop[0].selectedIndex == 0)
	{
		$("#spcat").html("<b style=\"color:red\">Choose Category</b>");
		return false;
	}
	if(styledrop[0].selectedIndex == 0)
	{
		$("#spstyle").html("<b style=\"color:red\">Choose Style</b>");
		return false;
	}
}

function hideMsg(e){

	let drop = e.target;
	if(drop.name == "category")
	{
		$("#spcat").html("");
	}
	if(drop.name == "style")
	{
		$("#spstyle").html("");	
	}
}