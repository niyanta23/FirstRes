$(document).ready(function(){
    $("#sign-up-as").click(showHideExtraFields);
    $("#register-form").submit(handleValidation);
    $("#copass").focusout(handlePasswordMatch);
    $("#copass").focusin(removePasswordError);
})

function showHideExtraFields(e){
    //e.currentTarget - sign-up-as
    //e.target - actual element (label/radio button)
    let targetElem = e.target;
    if(targetElem.name == "choice"){
        if(targetElem.id == "Designer"){
            $("#extra-field").removeClass("hide-fields");
        }
        else{
            $("#extra-field").addClass("hide-fields");
        }
    }
}

function handlePasswordMatch(e){
    // console.log(e);
    // console.log(e.target);
    let pass = $("#pass");
    let copass = $("#copass");
    // console.log(pass);
    // console.log(pass[0]);

    if(pass[0].value != copass[0].value){
        $("#errPass").removeClass("hide-fields").addClass("show-err-pass");
    }
}

function removePasswordError(e){
    $("#errPass").removeClass("show-err-pass").addClass("hide-fields");
}


function handleValidation(e){
    //id  #
    //class .
        
}