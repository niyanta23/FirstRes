from django.apps import AppConfig


class FappConfig(AppConfig):
    name = 'fapp'
