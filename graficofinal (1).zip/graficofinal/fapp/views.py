from django.shortcuts import render,redirect
from django.http import HttpResponse
from fapp.models import *
from django.contrib import messages
from datetime import date
import datetime
# Create your views here.

def header(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	try:
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
	except:
		pass

	return render(request,"header.html",data)

def home(request):

	data = {}

	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	
	if data["type"] == "C":
		allpackage=Package.objects.all()
		data["pkg"] = allpackage
		clnt = Client.objects.filter(C_Email=data["mail"])
		data["clnt"] = clnt

		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
		
		
	return render(request,"home.html",data)

def login(request):
	return render(request,"login.html")

def signup(request):
	return render(request,"signup.html")

def contactus1(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"contactus.html",data)	

def contactus(request,did):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["clnt"] = Client.objects.filter(C_Email=data["mail"])
	data["design"] = Designs.objects.filter(Design_Id=did)

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"Feedback.html",data)

def addFeedback(request):

	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	designid = request.POST["designid"]
	designerid = request.POST["designerid"]
	nm = request.POST["name"]
	msg = request.POST["message"]
	clientid = request.POST["clientid"]

	feedback = FeedBack.objects.create()

	feedback.F_Name = nm
	feedback.Feedback = msg

	dobj = Designs.objects.all()
	deobj = Designer.objects.all()
	cobj = Client.objects.all()

	for single in dobj:
		if single.Design_Id == int(designid):
			feedback.Design_Id = single
			
	for single in deobj:
		if single.D_Id == int(designerid):
			feedback.D_Id = single

	for single in cobj:
		if single.C_Id == int(clientid):
			feedback.C_Id = single

	feedback.save()

	data["msg"] = "Thank you for your feedback"

	return render(request,"Feedback.html",data)

def gallery(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["imgs"] = Designs.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"gallery.html",data)

def seeprofile(request,typeUser):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
	

	if typeUser == "D":
		data["degnr"] = Designer.objects.filter(D_Email=data["mail"])
		dgnr = Designer.objects.get(D_Email=data["mail"])

		try:
			data["design"] = Designs.objects.filter(D_Id=dgnr)
			data["fb"] = FeedBack.objects.filter(D_Id=dgnr)
			order = Orders.objects.filter(D_Id=dgnr)
			data["order"] = order
		except:
			pass

	else:
		data["clnt"] = Client.objects.filter(C_Email=data["mail"])
		print(data["mail"])

		try:
			clnt = Client.objects.get(C_Email=data["mail"])
			requi = Requirement.objects.filter(C_Id=clnt)
			data["requi"] = requi
		except:
			pass
		
	return render(request,"seeprofile.html",data)

def designerProfile(request,mail):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["degnr"] = Designer.objects.filter(D_Email=mail)
	dgnr = Designer.objects.get(D_Email=mail)
	data["design"] = Designs.objects.filter(D_Id=dgnr)
	data["fb"] = FeedBack.objects.filter(D_Id=dgnr)

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"designerProfile.html",data)

def cart(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"cart.html",data)

def viewproduct(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"viewproduct.html",data)

def payment(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"payment.html",data)

def Clientrequirement(request):
	category = Sub_Category.objects.all()
	styleOpt = StyleChoice.objects.all()
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["category"] = category
	data["style"] = styleOpt

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])


		requiCount = Requirement.objects.filter(C_Id=data["pkgclnt"]).count()
		
		limit =  data["pkgclnt"].P_Id.P_NoofRequirements

		if (requiCount < int(limit)):
			data["status"] = "Yes"
		else:
			data["status"] = "No"
		

		try:
			data["requi"] = Requirement.objects.filter(C_Id=data["pkgclnt"])	
		except:
			pass

	return render(request,"Clientrequirement.html",data)

def updateprofileclient(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["clnt"] = Client.objects.filter(C_Email=data["mail"])

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"updateprofileclient.html",data)	

def updateClient(request):
	
	name = request.POST["name"]
	email = request.POST["email"]
	pass1 = request.POST["pass"]
	contact = request.POST["cont"]
	gender = request.POST["radiobutton"]
	dob = request.POST["dob"]

	clnt = Client.objects.get(C_Email=request.session.get('user_mail'))

	clnt.C_Name = name
	clnt.C_Email = email
	clnt.C_Pass = pass1
	clnt.C_Contact = contact
	clnt.C_Gen = gender
	clnt.C_Dob = dob

	if len(request.FILES) != 0:
		img = request.FILES["img"]
		clnt.C_Photo = img

	clnt.save()

	request.session.flush()
	request.session.clear_expired()
	return redirect("/login")

def updateprofiledesigner(request):

	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["dgnr"] = Designer.objects.filter(D_Email=data["mail"])

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"updateprofiledesigner.html",data)

def updateDesigner(request):

	name = request.POST["name"]
	email = request.POST["email"]
	pass1 = request.POST["pass"]
	contact = request.POST["cont"]
	gender = request.POST["radiobutton"]
	dob = request.POST["dob"]


	degnr = Designer.objects.get(D_Email=request.session.get('user_mail'))

	degnr.D_Name = name
	degnr.D_Email = email
	degnr.D_Pass = pass1
	degnr.D_Contact = contact
	degnr.D_Gen = gender
	degnr.D_Dob = dob
	
	if len(request.FILES) != 0:
		img = request.FILES["img"]
		degnr.D_Photo = img

	try:
		degnr.D_Experience = request.POST["exp"]
	except:
		pass

	try:
		degnr.D_Jobstate = request.POST["state"]
	except:
		pass

	try:
		degnr.D_Qualification = request.POST["quali"]
	except:
		pass


	degnr.save()	

	request.session.flush()
	request.session.clear_expired()

	return redirect("/login")

def addData(request):

	name = request.POST["name"]
	email = request.POST["email"]
	pass1 = request.POST["pass"]
	contact = request.POST["cont"]
	gender = str(request.POST["gen"]).lower()
	dob = request.POST["dob"]

	try:
		img = request.FILES["userimg"]
	except:
		img = "fapp/static/images/user.png"

	user_type = request.POST["choice"]

	if(user_type == "D"):
		
		try:
			expr = request.POST["experience"]
		except:
			pass

		try:
			state = request.POST["state"]
		except:
			pass

		try:
			quali = request.POST["qualification"]
		except:
			pass


		degnr = Designer.objects.create()

		degnr.D_Name = name
		degnr.D_Email = email
		degnr.D_Pass = pass1
		degnr.D_Contact = contact
		degnr.D_Gen = gender
		degnr.D_Dob = dob
		degnr.D_Photo = img
		degnr.D_Experience = expr
		degnr.D_Jobstate = state
		degnr.D_Qualification = quali

		degnr.save()

	else:

		clnt = Client.objects.create()

		clnt.C_Name = name
		clnt.C_Email = email
		clnt.C_Pass = pass1
		clnt.C_Contact = contact
		clnt.C_Gen = gender
		clnt.C_Dob = dob
		clnt.C_Photo = img

		clnt.save()

	return render(request,"login.html")

def loginChk(request):

	flag = False

	degnr = Designer.objects.all()

	mail = request.POST["email"]
	pwd = request.POST["pass"]

	user_mail = mail
	user_type = ""

	for single in degnr:
		if single.D_Email == mail and single.D_Pass == pwd:
			flag = True
			user_type = "D"
			break;

	if flag == False:

		clnt = Client.objects.all()

		for single in clnt:
			if single.C_Email == mail and single.C_Pass == pwd:
				flag = True
				user_type = "C"
				break

	if flag:
		request.session['user_mail'] = user_mail
		request.session['user_type'] = user_type
		request.session.set_expiry(1000)	
		return redirect("/home")

	return render(request,"login.html",{"msg":"Login Failed. Try Again...."})

def logout(request):
	request.session.flush()
	request.session.clear_expired()
	return redirect("/home")

def addRequirement(request):

	category = request.POST['category']
	name = request.POST['name']
	slogan = request.POST['slogan']
	style = request.POST['style']
	color1 = request.POST['color1']
	color2 = request.POST['color2']
	color3 = request.POST['color3']
	desc = request.POST['desc']
	budget = request.POST['budget']

	reqObj = Requirement.objects.create()

	clntObj = Client.objects.all()
	for single in clntObj:
		if str(single.C_Email) == str(request.session.get('user_mail')):
			reqObj.C_Id = single

	catObj = Sub_Category.objects.all()
	for single in catObj:
		if str(single.Sub_Name) == category:
			reqObj.Sub_Category_Id = single

	styObj = StyleChoice.objects.all()
	for single in styObj:
		if str(single.Sty_Name) == style:
			reqObj.Style_Id = single

	reqObj.Requi_Budget = budget

	if name != "":
		reqObj.Requi_Name = name

	if slogan != "":
		reqObj.Requi_Slogan = slogan

	if desc != "":
		reqObj.Requi_Description = desc



	clrObj1 = Color.objects.create()
	clrObj1.c1 = color1
	clrObj1.c2 = color2
	clrObj1.c3 = color3
	clrObj1.save()
		
	clrObj = Color.objects.all()
	for single in clrObj:
		if single.c1 == color1 and single.c2 == color2 and single.c3 == color3:
			reqObj.Color_Id = single

	reqObj.save()

	return redirect("/seeRequirement")

def seeRequirement(request):

	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	subdata = {}

	clnt = Client.objects.filter(C_Email=data["mail"])

	if data["type"] == "C":

		try:
			reqObj = Requirement.objects.filter(C_Id=clnt[0])
			order = Orders.objects.filter(C_Id=clnt[0])
			data["order"] = order
			data["clnt"] = clnt
			data["reqObj"] = reqObj
		except:
			pass

	else:
		try:
			reqObj = Requirement.objects.all()
			order = Orders.objects.all()
			dgnr = Designer.objects.get(D_Email=data["mail"])
			dr = DesignerRequest.objects.filter(D_Id=dgnr)
			data["dr"] = dr
			data["order"] = order
			data["clnt"] = clnt
			data["reqObj"] = reqObj

			for single in reqObj:
				try:
				
					order1 = Orders.objects.get(Requi_Id=single)
					if order1.Payment_Status == "Yes":
						subdata[single.Requi_Id] = "completed"
						continue

					if order1.Payment_Status == "No" and order1.D_Id.D_Email != data["mail"]:
						subdata[single.Requi_Id] = "closed"
						continue
				
					for DRsingle in dr:
						if DRsingle.requi_Id.Requi_Id == single.Requi_Id:
							if DRsingle.D_Id.D_Email == data["mail"] and data["mail"] == order1.D_Id.D_Email:
								subdata[single.Requi_Id] = "chosen"
								continue

				except:

					for DRsingle in dr:
						
						if DRsingle.requi_Id.Requi_Id == single.Requi_Id:
							if DRsingle.D_Id.D_Email == data["mail"]:
								subdata[single.Requi_Id] = "sent"
								continue

		
			data["subdata"] = subdata

		except:
			pass

	return render(request,"seeRequirement.html",data)

def uploadDesign(request):
	designd = Designs.objects.all()
	subcategory = Sub_Category.objects.all()
	data={}
	data["subcategory"] = subcategory
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,'uploadDesign.html',data)

def Uploaddesignall(request):
	ccategory=request.POST['cat']
	subcate=request.POST['subcategory']
	img=request.POST['desimg']
	date=request.POST['date']
	pricee=request.POST['price']

	updesign = Designs.objects.create()
	destObj = Designer.objects.all()
	for single in destObj:
		if str(single.D_Id) == str(request.session.get('user_mail')):
			updesign.D_Id = single

	catObj = Category.objects.all()
	for single1 in catObj:
		if str(single1.Category_Name) == ccategory:
			updesign.Category_Id= single1

	subcatObj = Sub_Category.objects.all()
	for single in subcatObj:
		if str(single.Sub_Name) == subcate:
			updesign.Sub_Category_Id = single

	updesign.Design_Upload = date
	updesign.Design_Image = img
	updesign.Design_Price = pricee
	updesign.save()

	return redirect("/home")
		
def viewCategory(request,name):
	data = {}

	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	if name == "Brand & Identity" or name == "Book & Magazine" or name == "Clothing & Merchandise":
		cat = Category.objects.get(Category_Name=name)
		imgs = list(Designs.objects.filter(Category_Id=cat))
	else:	
		subCat = Sub_Category.objects.get(Sub_Name=name)
		imgs = list(Designs.objects.filter(Sub_Category_Id=subCat))

	data["imgs"] = imgs

	return render(request,"viewCategory.html",data)

def sendRequest(request,cid,dmail,requiid):

	dr = DesignerRequest.objects.create()

	dr.requi_Id = Requirement.objects.get(Requi_Id=requiid)
	dr.C_Id = Client.objects.get(C_Id=cid)
	dr.D_Id = Designer.objects.get(D_Email=dmail)

	dr.save()

	return redirect("/seeRequirement")

def selectDesigner(request,requiid):

	data = {}

	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	requi = Requirement.objects.get(Requi_Id=requiid)
	data["requi"] = requi

	dr = DesignerRequest.objects.filter(requi_Id=requi)
	data["dr"] = dr

	order = Orders.objects.filter(Requi_Id=requi).first()

	try:
		if order.D_Id:
			data["state"] = "Yes"
		else:
			data["state"] = "No"
	except:
		pass

	data["order"] = order

	return render(request,"selectDesigner.html",data)

def addOrder(request,cid,did,rid,bud):

	order = Orders.objects.create()

	clnt = Client.objects.get(C_Id=cid)
	dgnr = Designer.objects.get(D_Id=did)
	requi = Requirement.objects.get(Requi_Id=rid)

	order.C_Id = clnt
	order.D_Id = dgnr
	order.Requi_Id = requi
	order.Payment_Status = "No"
	order.Payment = bud

	order.save()

	return redirect("/selectDesigner/"+ rid +"")

def saveOrder(request,oid):

	order = Orders.objects.get(O_Id=oid)

	design = Designs.objects.create()

	design.D_Id = order.D_Id
	design.Category_Id = order.Requi_Id.Sub_Category_Id.Category_Id
	design.Sub_Category_Id = order.Requi_Id.Sub_Category_Id
	design.Design_Upload = date.today()
	design.Design_Image = request.FILES["designImg"]
	design.Design_Price = order.Requi_Id.Requi_Budget

	design.save()

	order.Design_Id = design
	order.Payment_Date = date.today()
	order.Payment_Status = "Yes"

	order.save()

	return redirect("/seeprofile/" + request.session.get('user_type'))

def seeRequirementDesigner(request,rid):

	data = {}

	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	data["requi"] = Requirement.objects.get(Requi_Id=rid)

	return render(request,"seeRequirementDesigner.html",data)

def packageid(request):

	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
	

	pid=request.POST["ipd"]
	
	searchd=Package.objects.filter(P_Id=pid)
	data["searchd"] = searchd
		
	return render(request,"package.html",data)

	#return redirect("/package",{"data":searchd})
def Adddatainctacle(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	flg=False

	pid=request.POST["ipd"]
	
	client_id=Client.objects.get(C_Email=request.session.get('user_mail'))
	client_id.P_Id=Package.objects.get(P_Id=pid)
	client_id.save()
	
	packData=Package_Buying_History.objects.all()
	for single in packData:
		if single.C_Id == client_id:
			flg=True
	
	if(flg==True):
		pack_Buy=Package_Buying_History.objects.filter(C_Id=client_id)
		pack_Buy.P_Id=Package.objects.get(P_Id=pid)
		pack_Buy.C_Id=Client.objects.get(C_Email=request.session.get('user_mail'))
		now = datetime.datetime.now()
		#pack_Buy.save()
		return render(request,"home.html")
	else:
		pack_Buy=Package_Buying_History.objects.create()
		pack_Buy.P_Id=Package.objects.get(P_Id=pid)
		pack_Buy.C_Id=Client.objects.get(C_Email=request.session.get('user_mail'))
		now = datetime.datetime.now()
		pack_Buy.Date_of_Buying=now
		pack_Buy.save()
		searchd=Package.objects.filter(P_Id=pid)
		data["searchd"] = searchd
		
		return render(request,"Paymentpkg.html",data)

def Paymentpkg(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
	
	allpackage=Package.objects.all()

	data["allpkg"] = allpackage
	return render(request,"Paymentpkg.html",data)

def package(request):

	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])
	
	allpackage=Package.objects.all()

	data["allpkg"] = allpackage

	return render(request,"packageid.html",data)

def deleteAccount(request):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')

	if( data["type"] == "C"):
		clnt = Client.objects.get(C_Email = request.session.get('user_mail'))

		try:
			requi = Requirement.objects.filter(C_Id=clnt)

			for single in requi:
				
				try:
					DesignerRequest.objects.filter(requi_Id=single).delete()
				except:
					pass

				try:
					Orders.objects.filter(Requi_Id=single).delete()
				except:
					pass

		except:
			pass

		Requirement.objects.filter(C_Id=clnt).delete()

		try:
			FeedBack.objects.filter(C_Id=clnt).delete()
		except:
			pass

		try:
			Package_Buying_History.objects.filter(C_Id=clnt).delete()
		except:
			pass

		clnt.delete()
		request.session.flush()
		request.session.clear_expired()

	if( data["type"] == "D"):
		degnr=Designer.objects.get(D_Email = request.session.get('user_mail'))

		try:
			Designs.objects.filter(D_Id=degnr).delete()
		except:
			pass

		try:
			FeedBack.objects.filter(D_Id=degnr).delete()
		except:
			pass

		try:
			DesignerRequest.objects.filter(D_Id=degnr).delete()
		except:
			pass


		degnr.delete()
		request.session.flush()
		request.session.clear_expired()

	return render(request,"login.html")

def  Feedback(request,did):
	data = {}
	data["mail"] = request.session.get('user_mail')
	data["type"] = request.session.get('user_type')
	data["cat"] = Category.objects.all()
	data["subcat"] = Sub_Category.objects.all()
	data["clnt"] = Client.objects.filter(C_Email=data["mail"])
	data["design"] = Designs.objects.filter(Design_Id=did)

	if data["type"] == "C":
		data["pkgclnt"] = Client.objects.get(C_Email=data["mail"])

	return render(request,"Feedback.html",data)