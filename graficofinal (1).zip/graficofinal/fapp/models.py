from django.db import models
# Create your models here.
class Package(models.Model):
	P_Id=models.AutoField(primary_key=True)
	P_Name=models.CharField(max_length=20,unique=True,null=True)
	P_NoofRequirements=models.CharField(max_length=10,null=True)
	P_Description=models.CharField(max_length=150,null=True)
	P_Cost=models.CharField(max_length=10,null=True)

	def __str__(self):
		return str(self.P_Id)+':'+self.P_Name+":"+str(self.P_NoofRequirements)+":"+self.P_Description+":"+str(self.P_Cost)

class Category(models.Model):
	Category_Id=models.AutoField(primary_key=True)
	Category_Name=models.CharField(max_length=30,null=True,unique=True)

	def __str__(self):
		return str(self.Category_Id)+':'+self.Category_Name

class Sub_Category(models.Model):
	Category_Id=models.ForeignKey(Category,on_delete=models.SET_NULL,null=True)
	Sub_Category_Id=models.AutoField(primary_key=True)
	Sub_Name=models.CharField(max_length=30,null=True,unique=True)

	def __str__(self):
		return str(self.Category_Id)+':'+str(self.Sub_Category_Id)+":"+self.Sub_Name

class StyleChoice(models.Model):
	Sty_Id = models.AutoField(primary_key=True)
	Sty_Name = models.CharField(max_length=30,unique=True)

	def __str__(self):
		return str(self.Sty_Id) + ":" + str(self.Sty_Name)

Gender=(('Male','Male'),
		('Female', 'Female'))
status=(('Yes','Yes'),
		('No', 'No'))

class Client(models.Model):
	C_Id=models.AutoField(primary_key=True)
	C_Name=models.CharField(max_length=30,null=True)
	C_Email=models.CharField(max_length=60,unique=True,null=True)
	C_Pass=models.CharField(max_length=8,null=True)
	C_Contact=models.CharField(max_length=10,null=True)
	C_Gen=models.CharField(max_length=60,null=True)
	C_Dob=models.DateField(null=True)
	C_Photo=models.ImageField(upload_to="fapp/static/images/client",null=True)
	P_Id=models.ForeignKey(Package,max_length=2,on_delete=models.SET_NULL,null=True)

	def __str__(self):
		return str(self.C_Id)+':'+str(self.C_Name)+":"+str(self.C_Email)+":"+str(self.C_Pass)+":"+str(self.C_Contact)+":"+str(self.C_Gen)+":"+str(self.C_Dob)+":"+str(self.C_Photo)+":"+str(self.P_Id)

class Package_Buying_History(models.Model):
	P_Id=models.ForeignKey(Package,max_length=2,on_delete=models.SET_NULL,null=True)
	C_Id=models.ForeignKey(Client,max_length=6,on_delete=models.SET_NULL,null=True)
	Date_of_Buying=models.DateField(null=True)

	def __str__(self):
		return str(self.P_Id)+':'+str(self.C_Id)+":"+str(self.Date_of_Buying)




class Color(models.Model):
	Color_Id=models.AutoField(primary_key=True)
	c1 = models.CharField(max_length=7)
	c2 = models.CharField(max_length=7)
	c3 = models.CharField(max_length=7)

	def __str__(self):
		return str(self.Color_Id) + ":" + str(self.c1) + ":" + str(self.c2) + ":" + str(self.c3)

class Requirement(models.Model):
	Requi_Id=models.AutoField(primary_key=True)
	C_Id=models.ForeignKey(Client,on_delete=models.SET_NULL,null=True)
	Requi_Name = models.CharField(max_length=50,null=True)
	Requi_Slogan = models.CharField(max_length=50,null=True)
	Sub_Category_Id=models.ForeignKey(Sub_Category,on_delete=models.SET_NULL,null=True)
	Style_Id=models.ForeignKey(StyleChoice,on_delete=models.SET_NULL,null=True)
	Color_Id=models.ForeignKey(Color,max_length=6,on_delete=models.SET_NULL,null=True)
	Requi_Description=models.CharField(max_length=300,null=True)
	Requi_Budget=models.IntegerField(null=True)

	def __str__(self):
		return str(self.Requi_Id) + ":" + str(self.C_Id) + ":" + str(self.Requi_Name) + ":" + str(self.Requi_Slogan) + ":" + str(self.Sub_Category_Id) + ":" + str(self.Style_Id) + ":" + str(self.Color_Id) + ":" + str(self.Requi_Description) + ":" + str(self.Requi_Budget)
		

class Designer(models.Model):
	D_Id=models.AutoField(primary_key=True)
	D_Name=models.CharField(max_length=30,null=True)
	D_Email=models.CharField(max_length=30,null=True,unique=True)
	D_Pass=models.CharField(max_length=8,null=True)
	D_Contact=models.CharField(max_length=10,help_text='Contact phone number')
	D_Gen=models.CharField(max_length=60,null=True)
	D_Dob=models.DateField(null=True)
	D_Photo=models.ImageField(upload_to="fapp/static/images/designer")
	D_Experience=models.CharField(max_length=10,null=True)
	D_Jobstate=models.CharField(choices=status,max_length=60)
	D_Qualification=models.CharField(max_length=10,null=True)

	def __str__(self):
		return str(self.D_Id)+':'+self.D_Name+":"+self.D_Email+":"+str(self.D_Pass)+":"+str(self.D_Contact)+":"+self.D_Gen+":"+str(self.D_Dob)+":"+str(self.D_Photo)
		+":"+str(self.D_Experience)+":"+self.D_Jobstate+":"+self.D_Qualification

class Designs(models.Model):
	Design_Id=models.AutoField(primary_key=True)
	D_Id=models.ForeignKey(Designer,on_delete=models.SET_NULL,null=True)
	Category_Id=models.ForeignKey(Category,on_delete=models.SET_NULL,null=True)
	Sub_Category_Id=models.ForeignKey(Sub_Category,on_delete=models.SET_NULL,null=True)
	Design_Upload=models.DateField(null=True)
	Design_Image=models.ImageField(upload_to="fapp/static/images/designs",null=True)
	Design_Price=models.CharField(max_length=20,default=100)

	def __str__(self):
		return str(self.Design_Id)+':'+str(self.D_Id)+":"+str(self.Sub_Category_Id)+":"+str(self.Design_Upload)+":"+str(self.Design_Image)+":"+str(self.Design_Price)

class Orders(models.Model):
	O_Id=models.AutoField(primary_key=True)
	C_Id=models.ForeignKey(Client,on_delete=models.SET_NULL,null=True)
	D_Id=models.ForeignKey(Designer,on_delete=models.SET_NULL,null=True)
	Requi_Id=models.ForeignKey(Requirement,on_delete=models.SET_NULL,null=True)
	Design_Id=models.ForeignKey(Designs,on_delete=models.SET_NULL,null=True)
	Payment_Status=models.CharField(choices=status,max_length=60)
	Payment=models.CharField(max_length=10,null=True)
	Payment_Date=models.DateField(null=True)

	def __str__(self):
		return str(self.O_Id)+':'+str(self.C_Id)+':'+str(self.D_Id)+':'+str(self.Requi_Id)+str(self.Design_Id)+':'+self.Payment_Status+":"+str(self.Payment)+":"+str(self.Payment_Date)

class FeedBack(models.Model):
	F_Id=models.AutoField(primary_key=True)
	F_Name=models.CharField(max_length=50,null=True)
	Feedback=models.CharField(max_length=300,null=True)
	D_Id=models.ForeignKey(Designer,on_delete=models.SET_NULL,null=True)
	C_Id=models.ForeignKey(Client,max_length=6,on_delete=models.SET_NULL,null=True)
	Design_Id=models.ForeignKey(Designs,max_length=6,on_delete=models.SET_NULL,null=True)

	def __str__(self):
		return str(self.F_Id)+":"+str(self.F_Name)+":"+str(self.Feedback)+":"+str(self.D_Id)+":"+str(self.C_Id)+":"+str(self.Design_Id)

class DesignerRequest(models.Model):
	R_Id=models.AutoField(primary_key=True)
	requi_Id = models.ForeignKey(Requirement,on_delete=models.SET_NULL,null=True)
	D_Id=models.ForeignKey(Designer,on_delete=models.SET_NULL,null=True)
	C_Id=models.ForeignKey(Client,max_length=6,on_delete=models.SET_NULL,null=True)

	def __str__(self):
		return str(self.R_Id)+":"+str(self.requi_Id)+":"+str(self.D_Id)+":"+str(self.C_Id)

