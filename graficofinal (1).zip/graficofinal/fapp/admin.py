from django.contrib import admin
from fapp.models import *
# Register your models here.

admin.site.register(Package)
admin.site.register(Category)
admin.site.register(Sub_Category)
admin.site.register(StyleChoice)
admin.site.register(Client)
admin.site.register(Package_Buying_History)
admin.site.register(Requirement)
admin.site.register(Color)
admin.site.register(Designer)
admin.site.register(Designs)
admin.site.register(Orders)
admin.site.register(FeedBack)
admin.site.register(DesignerRequest)